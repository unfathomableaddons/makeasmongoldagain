-- Block list.
local BLOCKED_WORDS = {
    "asmon",
	"olympus",
}

-- Normalize string.
local function normalize(str)
    return str:lower():gsub("[%s%p]+", "")
end

local function chatFilterFunc(self, event, msg, author)
    local normMsg = normalize(msg)
    local normAuthor = author and normalize(author) or ""
    for _, word in ipairs(BLOCKED_WORDS) do
        local normWord = normalize(word)
        if normMsg:find(normWord, 1, true) or normAuthor:find(normWord, 1, true) then
            return true -- suppress the message
        end
    end
    return false
end

local CHAT_EVENTS = {
    "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_CHANNEL",
    "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
    "CHAT_MSG_BATTLEGROUND", "CHAT_MSG_BATTLEGROUND_LEADER",
    "CHAT_MSG_AFK", "CHAT_MSG_DND",
    -- CHAT_MSG_BN_WHISPER -- Whispers intentionally excluded. Battle.net friends are opt-in on your end, so filtering it doesn't add anything. Remove comment to filter BNet Whispers.
}
for _, evt in ipairs(CHAT_EVENTS) do
    ChatFrame_AddMessageEventFilter(evt, chatFilterFunc)
end

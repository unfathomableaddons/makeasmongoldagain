-- No settings, no slash commands, no GUI. Two rules, checked in order:
--   1. If the SENDER'S NAME contains "asmon", the whole message goes gold.
--   2. Otherwise, if the MESSAGE TEXT contains "asmon", just that word goes gold.
-- Edit the word/color below and reload/relog if you ever want to change either.

local HIGHLIGHT_WORDS = {
    "asmon",
}

local HIGHLIGHT_COLOR = "ffd700" -- bright gold, WoW inline color hex (RRGGBB)

-- Colors the WHOLE word if any letters-only run (%a+) contains one of
-- HIGHLIGHT_WORDS as a substring — so "asmon" catches "Asmongold" and colors
-- all of "Asmongold", not just the "asmon" part of it. No need to list
-- "asmongold" separately; it's already covered because it contains "asmon".
local function highlightWholeWords(msg)
    return msg:gsub("%a+", function(word)
        local lowerWord = word:lower()
        for _, target in ipairs(HIGHLIGHT_WORDS) do
            if lowerWord:find(target, 1, true) then
                return "|cff" .. HIGHLIGHT_COLOR .. word .. "|r"
            end
        end
        -- returning nothing here leaves the word unchanged
    end)
end

local function chatFilterFunc(self, event, msg, author, ...)
    -- Rule 1: if the sender's own name contains "asmon", gild the whole message.
    if author and author:lower():find("asmon", 1, true) then
        local wholeMsgGold = "|cff" .. HIGHLIGHT_COLOR .. msg .. "|r"
        return false, wholeMsgGold, author, ...
    end

    -- Rule 2: otherwise, highlight the whole word wherever it appears.
    local highlighted = highlightWholeWords(msg)
    if highlighted ~= msg then
        return false, highlighted, author, ... -- let it through, but colored
    end

    return false -- no match, pass through untouched
end

local CHAT_EVENTS = {
    "CHAT_MSG_SAY", "CHAT_MSG_YELL", "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER",
    "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER", "CHAT_MSG_RAID_WARNING",
    "CHAT_MSG_GUILD", "CHAT_MSG_OFFICER", "CHAT_MSG_CHANNEL",
    "CHAT_MSG_EMOTE", "CHAT_MSG_TEXT_EMOTE",
    "CHAT_MSG_WHISPER",
    "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER",
    "CHAT_MSG_BATTLEGROUND", "CHAT_MSG_BATTLEGROUND_LEADER",
    "CHAT_MSG_AFK", "CHAT_MSG_DND",
}
for _, evt in ipairs(CHAT_EVENTS) do
    ChatFrame_AddMessageEventFilter(evt, chatFilterFunc)
end